***********************
EnergySystemModel class
***********************


.. |br| raw:: html

   <br />

A description of the class is given below.

**Class description:**

.. automodule:: energySystemModel
.. autoclass:: EnergySystemModel
   :members:
   :member-order: bysource

   .. automethod:: __init__
