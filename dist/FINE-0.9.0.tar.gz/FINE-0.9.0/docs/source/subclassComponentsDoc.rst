**************************
Extended component classes
**************************

.. |br| raw:: html

   <br />

Extended component classes can be declared as subclasses of the core component classes.
Current subclasses are

* LinearOptimalPowerFlow class

LinearOptimalPowerFlow class
############################

**Class description:**


.. automodule:: lopf
.. autoclass:: LinearOptimalPowerFlow
   :members:
   :member-order: bysource

   .. automethod:: __init__

**Inheritance diagram:**

.. inheritance-diagram:: LinearOptimalPowerFlow
   :parts: 1

